DO NOT COMMIT TO THE MASTER BRANCH. IF YOU DO I WILL HUNT YOU DOWN AND GUT YOU LIKE A FISH!!!
======

Make a fresh branch, make your changes, then make a pull request, and I will merge your changes in.